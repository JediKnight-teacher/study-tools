// ==========================================
// 📖 英語スピーチ台本データ (script-en-jp.js)
// ==========================================
const scriptENJP = [
 {
 en: `Good morning, everyone. Today, I'd like to talk about the power of effective communication.`,
 jp: `皆さん、おはようございます。本日は、効果的なコミュニケーションの力についてお話ししたいと思います。`
 },
 {
 en: `Learning a new language is not just about memorizing vocabulary and grammar rules.`,
 jp: `新しい言語を学ぶことは、単に単語や文法規則を記憶することだけではありません。`
 },
 {
 en: `It's about building connections and sharing your thoughts with confidence.`,
 jp: `大切なのは、人と人との繋がりを築き、自信を持って自分の考えを共有することです。`
 },
 {
 en: `By practicing every single day, you will gradually improve your pronunciation and natural rhythm.`,
 jp: `毎日練習を続けることで、発音や自然なリズムは少しずつ確実に上達していきます。`
 }
];
