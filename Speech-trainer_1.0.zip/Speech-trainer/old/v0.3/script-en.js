// ==========================================
// 📖 英文台本データ (script-en.js)
// ※セリフ内で引用符（"）を使えるよう、バッククォート(`)を使用しています。
// ==========================================
const scriptEN = [
  { "char": "Narrator", "text": `Hello, world.` },
  { "char": "Narrator", "text": `This is a test script.` },
  { "char": "Narrator", "text": `It's very easy to use!` }
];