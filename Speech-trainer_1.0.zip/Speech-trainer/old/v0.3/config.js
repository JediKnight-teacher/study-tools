// ==========================================
// ⚙️ アプリ基本設定＆話者・キャラクター設定ファイル (config.js)
// ==========================================
const appConfig = {
  title: "🎙️ マイ台本",
  subtitle: "自動生成された設定ファイル"
};

// 1. name: 画面上に表示されるキャラクターの名前です。
// 2. pitch: 声の高さ（0.1 ～ 2.0 の範囲で指定）
// 3. baseRate: 話すスピード（0.1 ～ 2.0 の範囲で指定）
// 4. color: 発言行の左端につく縦線の色（CSSのクラス名と連動）
const characterConfig = {
  "Narrator": { name: "ナレーション", pitch: 1.0, baseRate: 0.9, color: "char-Narration" }
};